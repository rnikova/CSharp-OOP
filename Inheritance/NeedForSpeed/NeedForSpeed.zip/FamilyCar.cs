﻿namespace NeedForSpeed
{
    public class FamilyCar : Car
    {
        public FamilyCar(double fuelConsumption, double fuel, int horsePower) 
            : base(fuelConsumption, fuel, horsePower)
        {
        }
    }
}
