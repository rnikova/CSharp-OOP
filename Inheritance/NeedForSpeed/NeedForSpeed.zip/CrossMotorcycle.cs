﻿namespace NeedForSpeed
{
    public class CrossMotorcycle : Motorcycle
    {
        public CrossMotorcycle(double fuelConsumption, double fuel, int horsePower) 
            : base(fuelConsumption, fuel, horsePower)
        {
        }
    }
}
