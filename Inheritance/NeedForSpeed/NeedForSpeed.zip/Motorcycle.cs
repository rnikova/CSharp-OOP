﻿namespace NeedForSpeed
{
    public class Motorcycle : Vehicle
    {
        public Motorcycle(double fuelConsumption, double fuel, int horsePower) 
            : base(fuelConsumption, fuel, horsePower)
        {
        }
    }
}
