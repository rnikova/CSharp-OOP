﻿namespace WildFarm.Models.Foods
{
    public interface IFood
    {
        int Quantity { get;}
    }
}
