﻿namespace WildFarm
{
    public static class ExceptionMessages
    {
        public static string InvalidFoodTypeException = "{0} does not eat {1}!";
    }
}
